import { inject, Injectable } from '@angular/core';
import { HttpClient, HttpParams } from '@angular/common/http';
import { environment } from '@env/environment';
import { FiltroGlobal } from '@core/models/filtoPaginado.model';
import { buildPaginationParams } from '@core/utils/paginacion-params';
import { Observable } from 'rxjs';
import { ActualizarGeneroDto, AgregarGeneroDto, GeneroDto } from '@core/models/generos.model';

@Injectable({
  providedIn: 'root',
})
export class GenerosService {
  private http: HttpClient = inject(HttpClient);
  private readonly apiUrl: string = `${environment.apiUrl}/api/v1/Genres`;

  obtenerGeneros(
    filtroPaginado: FiltroGlobal,
    pageNumber: number = 1,
    pageSize: number = 10,
  ): Observable<GeneroDto[]> {
    const params: HttpParams = buildPaginationParams(filtroPaginado, pageNumber, pageSize);

    return this.http.get<GeneroDto[]>(`${this.apiUrl}/paginado`, { params });
  }

  obtenerGeneroPorId(id: string): Observable<GeneroDto> {
    return this.http.get<GeneroDto>(`${this.apiUrl}/${id}`);
  }

  agregarGenero(genero: AgregarGeneroDto): Observable<GeneroDto> {
    return this.http.post<GeneroDto>(this.apiUrl, genero);
  }

  actualizarGenero(id: string, genero: ActualizarGeneroDto): Observable<void> {
    return this.http.put<void>(`${this.apiUrl}/${id}`, genero);
  }

  eliminarGenero(id: string): Observable<void> {
    return this.http.delete<void>(`${this.apiUrl}/${id}`);
  }
}
